--
-- PostgreSQL database dump
--

\restrict 6nQpMkUBhh0mFcXdmobEW8cqHHgA4uaxUcuETbMjfykHaN5fhfS85e9d6iYJ3DQ

-- Dumped from database version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Auth; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Auth" (
    id text NOT NULL,
    "userId" text
);


--
-- Name: AuthIdentity; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AuthIdentity" (
    "providerName" text NOT NULL,
    "providerUserId" text NOT NULL,
    "providerData" text DEFAULT '{}'::text NOT NULL,
    "authId" text NOT NULL
);


--
-- Name: ContactFormMessage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ContactFormMessage" (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "userId" text NOT NULL,
    content text NOT NULL,
    "isRead" boolean DEFAULT false NOT NULL,
    "repliedAt" timestamp(3) without time zone
);


--
-- Name: DailyStats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."DailyStats" (
    id integer NOT NULL,
    date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "totalViews" integer DEFAULT 0 NOT NULL,
    "prevDayViewsChangePercent" text DEFAULT '0'::text NOT NULL,
    "userCount" integer DEFAULT 0 NOT NULL,
    "paidUserCount" integer DEFAULT 0 NOT NULL,
    "userDelta" integer DEFAULT 0 NOT NULL,
    "paidUserDelta" integer DEFAULT 0 NOT NULL,
    "totalRevenue" double precision DEFAULT 0 NOT NULL,
    "totalProfit" double precision DEFAULT 0 NOT NULL
);


--
-- Name: DailyStats_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."DailyStats_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: DailyStats_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."DailyStats_id_seq" OWNED BY public."DailyStats".id;


--
-- Name: File; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."File" (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "userId" text NOT NULL,
    name text NOT NULL,
    type text NOT NULL,
    key text NOT NULL,
    "uploadUrl" text NOT NULL
);


--
-- Name: GptResponse; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."GptResponse" (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "userId" text NOT NULL,
    content text NOT NULL
);


--
-- Name: Logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Logs" (
    id integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    message text NOT NULL,
    level text NOT NULL
);


--
-- Name: Logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."Logs_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: Logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."Logs_id_seq" OWNED BY public."Logs".id;


--
-- Name: PageViewSource; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PageViewSource" (
    name text NOT NULL,
    date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "dailyStatsId" integer,
    visitors integer NOT NULL
);


--
-- Name: Session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Session" (
    id text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "userId" text NOT NULL
);


--
-- Name: Task; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Task" (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "userId" text NOT NULL,
    description text NOT NULL,
    "time" text DEFAULT '1'::text NOT NULL,
    "isDone" boolean DEFAULT false NOT NULL
);


--
-- Name: User; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."User" (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    email text,
    username text,
    "isAdmin" boolean DEFAULT false NOT NULL,
    "paymentProcessorUserId" text,
    "lemonSqueezyCustomerPortalUrl" text,
    "subscriptionStatus" text,
    "subscriptionPlan" text,
    "datePaid" timestamp(3) without time zone,
    credits integer DEFAULT 3 NOT NULL
);


--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- Name: DailyStats id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DailyStats" ALTER COLUMN id SET DEFAULT nextval('public."DailyStats_id_seq"'::regclass);


--
-- Name: Logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Logs" ALTER COLUMN id SET DEFAULT nextval('public."Logs_id_seq"'::regclass);


--
-- Data for Name: Auth; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Auth" (id, "userId") FROM stdin;
\.


--
-- Data for Name: AuthIdentity; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AuthIdentity" ("providerName", "providerUserId", "providerData", "authId") FROM stdin;
\.


--
-- Data for Name: ContactFormMessage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ContactFormMessage" (id, "createdAt", "userId", content, "isRead", "repliedAt") FROM stdin;
\.


--
-- Data for Name: DailyStats; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."DailyStats" (id, date, "totalViews", "prevDayViewsChangePercent", "userCount", "paidUserCount", "userDelta", "paidUserDelta", "totalRevenue", "totalProfit") FROM stdin;
\.


--
-- Data for Name: File; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."File" (id, "createdAt", "userId", name, type, key, "uploadUrl") FROM stdin;
\.


--
-- Data for Name: GptResponse; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."GptResponse" (id, "createdAt", "updatedAt", "userId", content) FROM stdin;
\.


--
-- Data for Name: Logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Logs" (id, "createdAt", message, level) FROM stdin;
\.


--
-- Data for Name: PageViewSource; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."PageViewSource" (name, date, "dailyStatsId", visitors) FROM stdin;
\.


--
-- Data for Name: Session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Session" (id, "expiresAt", "userId") FROM stdin;
\.


--
-- Data for Name: Task; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Task" (id, "createdAt", "userId", description, "time", "isDone") FROM stdin;
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."User" (id, "createdAt", email, username, "isAdmin", "paymentProcessorUserId", "lemonSqueezyCustomerPortalUrl", "subscriptionStatus", "subscriptionPlan", "datePaid", credits) FROM stdin;
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
e125070d-5ded-4fbe-a900-68b897151432	7139fddc5f6a4fb4994c549fd58f2ac8e170e183ba90c3314331e7a7bfe86ca2	2025-11-04 01:01:05.082447+03	20251103174759_	\N	\N	2025-11-04 01:01:04.99013+03	1
\.


--
-- Name: DailyStats_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."DailyStats_id_seq"', 1, false);


--
-- Name: Logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."Logs_id_seq"', 1, false);


--
-- Name: AuthIdentity AuthIdentity_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuthIdentity"
    ADD CONSTRAINT "AuthIdentity_pkey" PRIMARY KEY ("providerName", "providerUserId");


--
-- Name: Auth Auth_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Auth"
    ADD CONSTRAINT "Auth_pkey" PRIMARY KEY (id);


--
-- Name: ContactFormMessage ContactFormMessage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ContactFormMessage"
    ADD CONSTRAINT "ContactFormMessage_pkey" PRIMARY KEY (id);


--
-- Name: DailyStats DailyStats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DailyStats"
    ADD CONSTRAINT "DailyStats_pkey" PRIMARY KEY (id);


--
-- Name: File File_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."File"
    ADD CONSTRAINT "File_pkey" PRIMARY KEY (id);


--
-- Name: GptResponse GptResponse_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GptResponse"
    ADD CONSTRAINT "GptResponse_pkey" PRIMARY KEY (id);


--
-- Name: Logs Logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Logs"
    ADD CONSTRAINT "Logs_pkey" PRIMARY KEY (id);


--
-- Name: PageViewSource PageViewSource_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PageViewSource"
    ADD CONSTRAINT "PageViewSource_pkey" PRIMARY KEY (date, name);


--
-- Name: Session Session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_pkey" PRIMARY KEY (id);


--
-- Name: Task Task_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Task"
    ADD CONSTRAINT "Task_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: Auth_userId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Auth_userId_key" ON public."Auth" USING btree ("userId");


--
-- Name: DailyStats_date_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "DailyStats_date_key" ON public."DailyStats" USING btree (date);


--
-- Name: Session_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Session_id_key" ON public."Session" USING btree (id);


--
-- Name: Session_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Session_userId_idx" ON public."Session" USING btree ("userId");


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: User_paymentProcessorUserId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "User_paymentProcessorUserId_key" ON public."User" USING btree ("paymentProcessorUserId");


--
-- Name: User_username_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "User_username_key" ON public."User" USING btree (username);


--
-- Name: AuthIdentity AuthIdentity_authId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuthIdentity"
    ADD CONSTRAINT "AuthIdentity_authId_fkey" FOREIGN KEY ("authId") REFERENCES public."Auth"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Auth Auth_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Auth"
    ADD CONSTRAINT "Auth_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ContactFormMessage ContactFormMessage_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ContactFormMessage"
    ADD CONSTRAINT "ContactFormMessage_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: File File_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."File"
    ADD CONSTRAINT "File_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: GptResponse GptResponse_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GptResponse"
    ADD CONSTRAINT "GptResponse_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: PageViewSource PageViewSource_dailyStatsId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PageViewSource"
    ADD CONSTRAINT "PageViewSource_dailyStatsId_fkey" FOREIGN KEY ("dailyStatsId") REFERENCES public."DailyStats"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Session Session_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Auth"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Task Task_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Task"
    ADD CONSTRAINT "Task_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict 6nQpMkUBhh0mFcXdmobEW8cqHHgA4uaxUcuETbMjfykHaN5fhfS85e9d6iYJ3DQ

